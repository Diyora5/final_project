CREATE OR REPLACE FUNCTION bl_3nf.update_locality_name(loc_id INT, new_name VARCHAR(50)) 
RETURNS VOID AS $$
BEGIN
    UPDATE bl_3nf.ce_locality
    SET locality_name = new_name
    WHERE locality_id = loc_id;
    RETURN;
END;
$$ LANGUAGE plpgsql;

SELECT bl_3nf.update_locality_name(12, 'Berlin');

select * from bl_3nf.ce_locality where locality_id = '12'

CREATE VIEW bl_3nf.property_type_counts AS 
SELECT 
    cp.property_type, 
    COUNT(ch.property_id) AS num_properties
FROM 
    bl_3nf.ce_property cp 
    JOIN bl_3nf.ce_house ch ON ch.property_id = cp.property_id
GROUP BY 
    cp.property_type;
 
SELECT * FROM bl_3nf.property_type_counts LIMIT 3;