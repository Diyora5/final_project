-- Create dm_year dimension table
CREATE TABLE bl_dm.dm_year (
    year_id SERIAL PRIMARY KEY,
    year INT
);
 

INSERT INTO bl_dm.dm_year (year)
SELECT DISTINCT year
FROM bl_dm.fact_house;

-- Create dm_date dimension table
CREATE TABLE bl_dm.dm_date (
    date_id SERIAL PRIMARY KEY,
    date DATE,
    year_id INT,
    month INT,
    day INT,
    day_of_week VARCHAR(9),
    FOREIGN KEY (year_id) REFERENCES bl_dm.dm_year(year_id)
);

INSERT INTO bl_dm.dm_date (date, year_id, month, day, day_of_week)
SELECT DISTINCT 
    TO_DATE(date, 'DD/MM/YYYY'),
    y.year_id,
    EXTRACT(MONTH FROM TO_DATE(date, 'DD/MM/YYYY')),
    EXTRACT(DAY FROM TO_DATE(date, 'DD/MM/YYYY')),
    TO_CHAR(TO_DATE(date, 'DD/MM/YYYY'), 'Day')
FROM bl_dm.fact_house f
JOIN bl_dm.dm_year y ON f.year = y.year;

-- Create dm_locality dimension table
CREATE TABLE bl_dm.dm_locality (
    locality_id SERIAL PRIMARY KEY,
    locality_name VARCHAR(50)
);

INSERT INTO bl_dm.dm_locality (locality_name)
SELECT DISTINCT locality
FROM bl_dm.fact_house;

-- Create dm_address dimension table
CREATE TABLE bl_dm.dm_address (
    address_id SERIAL PRIMARY KEY,
    address VARCHAR(100),
    locality_id INT,
    FOREIGN KEY (locality_id) REFERENCES bl_dm.dm_locality(locality_id)
);

INSERT INTO bl_dm.dm_address (address, locality_id)
SELECT DISTINCT f.address, l.locality_id
FROM bl_dm.fact_house f
JOIN bl_dm.dm_locality l ON f.locality = l.locality_name;

-- Create dm_property dimension table
CREATE TABLE bl_dm.dm_property (
    property_id SERIAL PRIMARY KEY,
    property_type VARCHAR(50),
    residential_type VARCHAR(50)
);

INSERT INTO bl_dm.dm_property (property_type, residential_type)
SELECT DISTINCT property, residential
FROM bl_dm.fact_house;

-- Update fact_house table with new dimension keys
ALTER TABLE bl_dm.fact_house
ADD COLUMN dm_date_id INT,
ADD COLUMN dm_address_id INT,
ADD COLUMN dm_property_id INT;

UPDATE bl_dm.fact_house f
SET 
    dm_date_id = d.date_id,
    dm_address_id = a.address_id,
    dm_property_id = p.property_id
FROM 
    bl_dm.dm_date d,
    bl_dm.dm_address a,
    bl_dm.dm_property p
WHERE 
    TO_DATE(f.date, 'DD/MM/YYYY') = d.date
    AND f.address = a.address
    AND f.property = p.property_type
    AND f.residential = p.residential_type;

-- Add foreign key constraints to fact_house
ALTER TABLE bl_dm.fact_house
ADD CONSTRAINT fk_fact_house_date FOREIGN KEY (dm_date_id) REFERENCES bl_dm.dm_date(date_id),
ADD CONSTRAINT fk_fact_house_address FOREIGN KEY (dm_address_id) REFERENCES bl_dm.dm_address(address_id),
ADD CONSTRAINT fk_fact_house_property FOREIGN KEY (dm_property_id) REFERENCES bl_dm.dm_property(property_id);

-- Create indexes for better query performance
CREATE INDEX idx_fact_house_dm_date_id ON bl_dm.fact_house(dm_date_id);
CREATE INDEX idx_fact_house_dm_address_id ON bl_dm.fact_house(dm_address_id);
CREATE INDEX idx_fact_house_dm_property_id ON bl_dm.fact_house(dm_property_id);