


CREATE TABLE bl_3nf.ce_address (
  address_id SERIAL PRIMARY KEY,
  locality_id INT,
  street VARCHAR(100),
  FOREIGN KEY (locality_id) REFERENCES bl_3nf.ce_locality(locality_id)
);

CREATE TABLE bl_3nf.ce_carpet_area (
  carpet_area_id SERIAL PRIMARY KEY,
  area FLOAT
);

CREATE TABLE bl_3nf.ce_date (
  date_id SERIAL PRIMARY KEY,
  date varchar,
  year INT
);

CREATE TABLE bl_3nf.ce_locality (
  locality_id SERIAL PRIMARY KEY,
  locality_name VARCHAR(50)
);

CREATE TABLE bl_3nf.ce_property (
  property_id SERIAL PRIMARY KEY,
  property_type VARCHAR(50)
);

CREATE TABLE bl_3nf.ce_property_tax_rate (
  property_tax_rate_id SERIAL PRIMARY KEY,
  tax_rate FLOAT
);

CREATE TABLE bl_3nf.ce_property_value (
  property_value_id SERIAL PRIMARY KEY,
  sale_price FLOAT,
  estimated_value FLOAT
);

CREATE TABLE bl_3nf.ce_residential (
  residential_id SERIAL PRIMARY KEY,
  residential_type VARCHAR(50)
);

CREATE TABLE bl_3nf.ce_rooms (
  room_id SERIAL PRIMARY KEY,
  number_of_rooms INT
);

-- Assume ce_house table exists with initial imported data.
-- Add ce_property_date for many-to-many relationship between property and date
CREATE TABLE bl_3nf.ce_property_date (
  property_id INT,
  date_id INT,
  PRIMARY KEY (property_id, date_id),
  FOREIGN KEY (property_id) REFERENCES bl_3nf.ce_property(property_id),
  FOREIGN KEY (date_id) REFERENCES bl_3nf.ce_date(date_id)
);


-- Add foreign keys
ALTER TABLE bl_3nf.ce_house
ADD COLUMN address_id INT,
ADD FOREIGN KEY (address_id) REFERENCES bl_3nf.ce_address(address_id);

ALTER TABLE bl_3nf.ce_house
ADD COLUMN carpet_area_id INT,
ADD FOREIGN KEY (carpet_area_id) REFERENCES bl_3nf.ce_carpet_area(carpet_area_id);

ALTER TABLE bl_3nf.ce_house
ADD COLUMN property_id INT,
ADD FOREIGN KEY (property_id) REFERENCES bl_3nf.ce_property(property_id);

ALTER TABLE bl_3nf.ce_house
ADD COLUMN property_tax_rate_id INT,
ADD FOREIGN KEY (property_tax_rate_id) REFERENCES bl_3nf.ce_property_tax_rate(property_tax_rate_id);

ALTER TABLE bl_3nf.ce_house
ADD FOREIGN KEY (property_value_id) REFERENCES bl_3nf.ce_property_value(property_value_id);

ALTER TABLE bl_3nf.ce_house
ADD COLUMN residential_id INT,
ADD FOREIGN KEY (residential_id) REFERENCES bl_3nf.ce_residential(residential_id);

ALTER TABLE bl_3nf.ce_house
ADD COLUMN room_id INT,
ADD FOREIGN KEY (room_id) REFERENCES bl_3nf.ce_rooms(room_id);

-- Update foreign key columns
UPDATE bl_3nf.ce_house AS ch
SET address_id = (SELECT address_id FROM bl_3nf.ce_address WHERE street = ch.address),
    carpet_area_id = (SELECT carpet_area_id FROM bl_3nf.ce_carpet_area WHERE area = ch.carpet_area),
    property_id = (SELECT property_id FROM bl_3nf.ce_property WHERE property_type = ch.property),
    property_tax_rate_id = (SELECT property_tax_rate_id FROM bl_3nf.ce_property_tax_rate WHERE tax_rate = ch.property_tax_rate),
    property_value_id = (SELECT property_value_id FROM bl_3nf.ce_property_value WHERE sale_price = ch.sale_price AND estimated_value = ch.estimated_value),
    residential_id = (SELECT residential_id FROM bl_3nf.ce_residential WHERE residential_type = ch.Residential),
    room_id = (SELECT room_id FROM bl_3nf.ce_rooms WHERE number_of_rooms = ch.num_rooms)
    
    
-- Insert:
insert into bl_3nf.ce_locality(locality_name)
select distinct locality from bl_3nf.ce_house 

select * from bl_3nf.ce_locality cl 

insert into bl_3nf.ce_address(address)
select distinct address from bl_3nf.ce_house 

select * from bl_3nf.ce_address ca 

insert into bl_3nf.ce_carpet_area(carpet_area)
select distinct carpet_area from bl_3nf.ce_house 

select * from bl_3nf.ce_carpet_area cca

insert into bl_3nf.ce_date("date")
select distinct date from bl_3nf.ce_house 

select * from bl_3nf.ce_date cd 

insert into bl_3nf.ce_property(property_type)
select distinct property from bl_3nf.ce_house 

select * from bl_3nf.ce_property_date cpd 

insert into bl_3nf.ce_property_tax_rate(tax_rate)
select distinct property_tax_rate from bl_3nf.ce_house 

select * from bl_3nf.ce_property_tax_rate cptr 

insert into bl_3nf.ce_property_value(sale_price)
select distinct sale_price from bl_3nf.ce_house 

select * from bl_3nf.ce_property_value cpv 

insert into bl_3nf.ce_residential (residential_type)
select distinct residential from bl_3nf.ce_house 

select * from bl_3nf.ce_residential

insert into bl_3nf.ce_rooms (number_of_rooms)
select distinct num_rooms from bl_3nf.ce_house 

select * from bl_3nf.ce_rooms cr 

insert into bl_3nf.ce_property_value (sale_price, estimated_value)
select distinct sale_price, estimated_value from bl_3nf.ce_house 

select * from bl_3nf.ce_property_value cpv 

insert into bl_3nf.ce_residential (residential_type)
select distinct residential from bl_3nf.ce_house 

select * from bl_3nf.ce_residential cr 

insert into bl_3nf.ce_rooms (number_of_rooms)
select distinct num_rooms from bl_3nf.ce_house 

select * from bl_3nf.ce_rooms cr 

INSERT INTO ce_property_date (property_id, date_id)
SELECT cp.property_id, cd.date_id
FROM ce_house ch
JOIN ce_property cp ON ch.property = cp.property_type
JOIN ce_date cd ON ch.date = cd.date
ON CONFLICT DO NOTHING;

update bl_3nf.ce_house as hs
set address_id = ad.address_id
from bl_3nf.ce_address as ad
where hs.address =  ad.address 

update bl_3nf.ce_house as hs
set carpet_area_id = ad.area_id
from bl_3nf.ce_carpet_area as ad
where hs.carpet_area =  ad.carpet_area 

update bl_3nf.ce_house as hs
set property_id = ad.property_id
from bl_3nf.ce_property as ad
where hs.property =  ad.property_type 

update bl_3nf.ce_house as hs
set property_tax_rate_id = ad.property_tax_rate_id 
from bl_3nf.ce_property_tax_rate as ad
where hs.property_tax_rate =  ad.tax_rate 

update bl_3nf.ce_house as hs
set property_value_id = ad.property_value_id 
from bl_3nf.ce_property_value as ad
where hs.estimated_value =  ad.estimated_value 

update bl_3nf.ce_address as ad  
set locality_id = lo.locality_id
from ce_locality as lo
join bl_3nf.ce_house hs on lo.locality_name = hs.locality 

update bl_3nf.ce_house as hs
set residential_id = ad.residential_id
from bl_3nf.ce_residential as ad
where hs.residential =  ad.residential_type 

update bl_3nf.ce_house as hs
set room_id = ad.room_id
from bl_3nf.ce_rooms as ad
where hs.num_rooms =  ad.number_of_rooms 

ALTER TABLE bl_3nf.ce_house 
DROP COLUMN locality,
drop column address,
drop column estimated_value,
drop column sale_price,
drop column property,
drop column residential,
drop column num_rooms,
drop column carpet_area,
drop column property_tax_rate


