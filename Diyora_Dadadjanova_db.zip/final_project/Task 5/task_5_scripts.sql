--1. What is the highest sale price of properties by month and locality for 2009?
SELECT 
    TO_CHAR(d.date, 'MM') AS month,
    l.locality_name,
    MAX(f.sale_price) AS avg_sale_price
FROM bl_dm.fact_house f
JOIN bl_dm.dm_date d ON f.dm_date_id = d.date_id
JOIN bl_dm.dm_address a ON f.dm_address_id = a.address_id
JOIN bl_dm.dm_locality l ON a.locality_id = l.locality_id
GROUP BY TO_CHAR(d.date, 'MM'), l.locality_name
ORDER BY avg_sale_price DESC
limit 10;

--2. Which property type has the highest average sale price per square foot (carpet area)?
SELECT 
    p.property_type,
    AVG(f.sale_price / f.carpet_area) AS avg_price_per_sqft
FROM bl_dm.fact_house f
JOIN bl_dm.dm_property p ON f.dm_property_id = p.property_id
GROUP BY p.property_type
ORDER BY avg_price_per_sqft DESC;

--3. What is the monthly trend of property sales for 2009?
SELECT 
    TO_CHAR(d.date, 'MM') AS month,
    COUNT(*) AS sales_count,
    MAX(f.sale_price) AS avg_sale_price
FROM bl_dm.fact_house f
JOIN bl_dm.dm_date d ON f.dm_date_id = d.date_id
GROUP BY TO_CHAR(d.date, 'MM')
ORDER BY month;

--4. What are the top 5 localities with the highest average sale price for properties with more than 2 rooms?
SELECT 
    l.locality_name,
    AVG(f.sale_price) AS avg_sale_price,
    COUNT(*) AS property_count
FROM bl_dm.fact_house f
JOIN bl_dm.dm_address a ON f.dm_address_id = a.address_id
JOIN bl_dm.dm_locality l ON a.locality_id = l.locality_id
WHERE f.num_rooms > 2
GROUP BY l.locality_name
HAVING COUNT(*) > 5  -- To ensure we have a meaningful sample size
ORDER BY avg_sale_price DESC
LIMIT 5;


